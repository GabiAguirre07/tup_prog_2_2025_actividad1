﻿using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace Ej1
{
    internal class Ortoedro
    {
        Rectangulo r1 = new Rectangulo(3,6);
        Rectangulo r2 = new Rectangulo(3,3);
        public Rectangulo[] Laterales = new Rectangulo[4];
        public Rectangulo[] Bases = new Rectangulo[2];
        public Ortoedro (double AnchoBase,double ladoComun,double LargoLateral)
        {
            Bases[0] = new Rectangulo (AnchoBase, ladoComun);
            Bases[1] = new Rectangulo(AnchoBase, ladoComun);
            Laterales[0] = new Rectangulo(AnchoBase, ladoComun);
            Laterales[1] = new Rectangulo(AnchoBase, ladoComun);
            Laterales[2] = new Rectangulo(AnchoBase, ladoComun);
            Laterales[3] = new Rectangulo(AnchoBase, ladoComun);

        }
       
        public double CalcularArea()
        {
          double areaBase = Bases[0].CalcularArea();
           double areaLateral = Laterales[0].CalcularArea();
            return areaBase * 2 + areaLateral * 4;  
        }
        public double CalcularVolumen()
        {
            double volumen = Bases[0].CalcularArea() * Laterales[0].Largo;
            return volumen;
        }
            public string Describir()
        {
            return " Area: " + CalcularArea() + " Volumen: " + CalcularVolumen();
        }
        }
    }


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ej1
{
    internal class Rectangulo
    {
        public double Ancho {  get; set; }
        public double Largo { get; set; }
        public Rectangulo(double Ancho, double Largo)
        {
            this.Ancho = Ancho;
            this.Largo = Largo;
        }
        public double CalcularArea()
            { return Ancho * Largo; }
        public string Describir ()
        {
            return "Es un Rectángulo";
        }
    }
}
